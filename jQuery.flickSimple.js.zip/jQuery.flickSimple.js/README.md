# jQuery.flickSimple.js

iPhoneの特徴的なインタフェースであるフリック操作を、Webサイト上で実現するための jQueryプラグインです。

## Demos and documentation

[http://d.hatena.ne.jp/makog/20110526/1306428975](http://d.hatena.ne.jp/makog/20110526/1306428975)
